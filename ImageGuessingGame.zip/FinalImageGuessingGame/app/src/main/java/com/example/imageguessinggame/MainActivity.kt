package com.example.imageguessinggame

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.imageguessinggame.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var fruits = mutableListOf(R.drawable.grapes,R.drawable.apple, R.drawable.orange)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val gameSwitch = binding.switchGame

        val buttons = mutableListOf<Button>()
        buttons.add(binding.btnGrape)
        buttons.add(binding.btnRandom)
        buttons.add(binding.btnApple)

        gameSwitch.setOnCheckedChangeListener { _, isChecked ->

            for (button in buttons) {
                button.isEnabled = isChecked
            }

            if (!isChecked) {
                binding.imgGuessView.setImageResource(R.drawable.empty)
                binding.imgYourGuesView.setImageResource(R.drawable.empty)

                Snackbar.make(
                    findViewById(android.R.id.content),
                    "Please turn on the switch to start the game.",
                    Snackbar.LENGTH_SHORT
                ).show()
            }
            else{
                Snackbar.make(
                    findViewById(android.R.id.content),
                    "Game is now starting...",
                    Snackbar.LENGTH_SHORT
                ).show()
            }
        }//setOnCheckedChange
        for (button in buttons) {
            button.setOnClickListener {
                if (gameSwitch.isChecked) {

                    //if the switch is turned on
                    binding.btnApple.setOnClickListener{
                        binding.imgYourGuesView.setImageResource(R.drawable.apple)
                    }

                    binding.btnGrape.setOnClickListener{
                        binding.imgYourGuesView.setImageResource(R.drawable.grapes)
                    }

                    binding.btnRandom.setOnClickListener {

                        val r = (fruits).shuffled().first()
                        binding.imgGuessView.setImageResource(r)

                        var randomGuess = binding.imgGuessView.drawable
                        var playerGuess = binding.imgYourGuesView.drawable

                            //display the current state of the ImageView.
                        if (randomGuess.constantState == playerGuess.constantState) {
                            Snackbar.make(it, "Correct!", Snackbar.LENGTH_SHORT).show()
                        } else {
                            Snackbar.make(it, "Incorrect!", Snackbar.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    // if the user have not yet switch
                    Snackbar.make(
                        findViewById(android.R.id.content),
                        "Please turn on the switch to start the game.",
                        Snackbar.LENGTH_SHORT
                    ).show()
                }
            }
        }



    }
}